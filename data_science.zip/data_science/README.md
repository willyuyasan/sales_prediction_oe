# Data science for sales prediction exercise

this part have 5 steps to be followed to understand how the input data where treated in order to produce a predictive model for estimate new sales for future dates

The steps are considered one by one on the following notebooks and in the respective order:

- 01_Imports_data
- 02_Data_cleaning_and_description
- 03_Data_modelling_ts (time series)
- 04_Generates_predictions

Feel free of explore the notebooks!

Likewise as the main goal is to procude prediction of  given file (.csv), where new dates are delivered waiting for its number of predicted sales, then the user can see the final deliverable file (.csv) with the same estructure as the given one, on the "predictions" folder.

As mentioned before, the delivered file maintain the initial given estructure, but with the "q_predicted" field filled with the expected prediction, and with a new one field "prediction_datetime" where is stored the prediction date


--Author: William Uyasan

